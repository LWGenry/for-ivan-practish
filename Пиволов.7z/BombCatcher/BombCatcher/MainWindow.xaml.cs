﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using System.Xml.Serialization;

namespace BombCatcher
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer gameTimer = new DispatcherTimer();
        private DispatcherTimer positionTimer = new DispatcherTimer();
        private Dictionary<Bomb, EventHandler> bombEventHandlers = new Dictionary<Bomb, EventHandler>();
        private Dictionary<Bomb, Storyboard> activeBombs = new Dictionary<Bomb, Storyboard>();
        private int missed = 0;
        private int caught = 0;
        private double speed = 2;
        private DateTime lastDifficultyIncrease = DateTime.Now;
        private string playerName = "Игрок";
        private List<PlayerScore> highScores = new List<PlayerScore>();
        private const string ScoresFile = "highscores.xml";

        public MainWindow()
        {
            InitializeComponent();
            LoadHighScores();
            UpdateHighScoresDisplay();

            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Interval = TimeSpan.FromSeconds(1.3);

            positionTimer.Interval = TimeSpan.FromMilliseconds(100);
            positionTimer.Tick += PositionCheck_Tick;
            positionTimer.Start();
        }

        private void LoadHighScores()
        {
            if (File.Exists(ScoresFile))
            {
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(List<PlayerScore>));
                    using (FileStream stream = File.OpenRead(ScoresFile))
                    {
                        highScores = (List<PlayerScore>)serializer.Deserialize(stream);
                    }
                }
                catch { /* Если файл поврежден, начнем с пустого списка */ }
            }
        }

        private void SaveHighScores()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<PlayerScore>));
            using (FileStream stream = File.Create(ScoresFile))
            {
                serializer.Serialize(stream, highScores);
            }
        }

        private void UpdateHighScoresDisplay()
        {
            highScoresPanel.Children.Clear();
            highScoresPanel.Children.Add(new TextBlock
            {
                Text = "Лучшие алкаши",
                Margin = new Thickness(0, 0, 0, 10),
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center
            });

            var topScores = highScores.OrderByDescending(p => p.Score).Take(5).ToList();

            for (int i = 0; i < topScores.Count; i++)
            {
                var score = topScores[i];
                highScoresPanel.Children.Add(new TextBlock
                {
                    Text = $"{i + 1}. {score.Name}: {score.Score}",
                    Margin = new Thickness(0, 0, 0, 5),
                    FontSize = 16,
                    FontWeight = i == 0 ? FontWeights.Bold : FontWeights.Normal,
                    Foreground = i == 0 ? Brushes.Gold : Brushes.Black
                });
            }
        }

        private void AddCurrentScore()
        {
            var inputDialog = new InputDialog("Введите ваше имя:", playerName);
            if (inputDialog.ShowDialog() == true)
            {
                playerName = inputDialog.Answer;
                highScores.Add(new PlayerScore { Name = playerName, Score = caught, Date = DateTime.Now });
                SaveHighScores();
                UpdateHighScoresDisplay();
            }
        }

        private void PositionCheck_Tick(object sender, EventArgs e)
        {
            foreach (var bomb in activeBombs.Keys.ToList())
            {
                bomb.CheckPosition(gameCanvas.ActualHeight);
            }
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            missed = 0;
            caught = 0;
            txtMissed.Text = "0";
            txtCaught.Text = "0";
            speed = 2;
            gameTimer.Interval = TimeSpan.FromSeconds(1.3);

            gameTimer.Start();
            btnStart.IsEnabled = false;
            lastDifficultyIncrease = DateTime.Now;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            Bomb bomb = new Bomb();
            bomb.IsFalling = true;

            EventHandler handler = (s, args) =>
            {
                Dispatcher.Invoke(() =>
                {
                    if (bomb.IsFalling)
                    {
                        missed++;
                        txtMissed.Text = missed.ToString();
                        if (missed >= 5) EndGame();
                        CleanUpBomb(bomb);
                    }
                });
            };

            bomb.Missed += handler;
            bombEventHandlers[bomb] = handler;

            Random rand = new Random();
            Canvas.SetLeft(bomb, rand.Next(0, (int)(gameCanvas.ActualWidth - 30)));
            Canvas.SetTop(bomb, -70);
            gameCanvas.Children.Add(bomb);

            Storyboard storyboard = new Storyboard();
            DoubleAnimation fallAnimation = new DoubleAnimation
            {
                To = gameCanvas.ActualHeight,
                Duration = TimeSpan.FromSeconds(5 - speed)
            };

            Storyboard.SetTarget(fallAnimation, bomb);
            Storyboard.SetTargetProperty(fallAnimation, new PropertyPath(Canvas.TopProperty));

            DoubleAnimation rotateAnimation = new DoubleAnimation
            {
                From = -10,
                To = 10,
                Duration = TimeSpan.FromSeconds(0.8),
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            var transform = bomb.FindName("BottleRotateTransform") as RotateTransform;
            Storyboard.SetTarget(rotateAnimation, transform);
            Storyboard.SetTargetProperty(rotateAnimation, new PropertyPath(RotateTransform.AngleProperty));

            storyboard.Children.Add(fallAnimation);
            storyboard.Children.Add(rotateAnimation);
            storyboard.Completed += (s, args) =>
            {
                Dispatcher.Invoke(() =>
                {
                    if (bomb.IsFalling)
                    {
                        missed++;
                        txtMissed.Text = missed.ToString();
                        if (missed >= 5) EndGame();
                    }
                    CleanUpBomb(bomb);
                });
            };

            activeBombs.Add(bomb, storyboard);
            storyboard.Begin();

            if ((DateTime.Now - lastDifficultyIncrease).TotalSeconds > 8)
            {
                speed += 0.5;
                gameTimer.Interval = TimeSpan.FromSeconds(gameTimer.Interval.TotalSeconds * 0.8);
                lastDifficultyIncrease = DateTime.Now;
            }
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DependencyObject source = e.OriginalSource as DependencyObject;
            while (source != null && !(source is Bomb))
            {
                source = VisualTreeHelper.GetParent(source);
            }

            if (source is Bomb bomb && bomb.IsFalling)
            {
                bomb.IsFalling = false;
                caught++;
                Dispatcher.Invoke(() => txtCaught.Text = caught.ToString());

                Storyboard hitStoryboard = new Storyboard();
                DoubleAnimation hitAnimation = new DoubleAnimation
                {
                    To = -100,
                    Duration = TimeSpan.FromSeconds(0.5)
                };
                Storyboard.SetTarget(hitAnimation, bomb);
                Storyboard.SetTargetProperty(hitAnimation, new PropertyPath(Canvas.TopProperty));
                hitStoryboard.Children.Add(hitAnimation);
                hitStoryboard.Completed += (s, _) => CleanUpBomb(bomb);
                hitStoryboard.Begin();
            }
        }

        private void CleanUpBomb(Bomb bomb)
        {
            if (!activeBombs.ContainsKey(bomb)) return;

            if (bombEventHandlers.TryGetValue(bomb, out EventHandler handler))
            {
                bomb.Missed -= handler;
                bombEventHandlers.Remove(bomb);
            }

            activeBombs[bomb].Stop();
            gameCanvas.Children.Remove(bomb);
            activeBombs.Remove(bomb);
        }

        private void EndGame()
        {
            gameTimer.Stop();
            positionTimer.Stop();

            foreach (var bomb in activeBombs.Keys.ToList())
            {
                CleanUpBomb(bomb);
            }

            AddCurrentScore();

            btnStart.IsEnabled = true;
            MessageBox.Show($"Игра окончена! Поймано бутылок: {caught}");
            missed = 0;
            caught = 0;
            txtMissed.Text = "0";
            txtCaught.Text = "0";
            speed = 2;
            gameTimer.Interval = TimeSpan.FromSeconds(1.3);
            positionTimer.Start();
        }
    }

    public class PlayerScore
    {
        public string Name { get; set; }
        public int Score { get; set; }
        public DateTime Date { get; set; }
    }

    public class InputDialog : Window
    {
        public string Answer { get; private set; }

        public InputDialog(string prompt, string defaultAnswer = "")
        {
            Width = 300;
            Height = 150;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Title = "Рекорд!";

            var stackPanel = new StackPanel { Margin = new Thickness(10) };

            stackPanel.Children.Add(new TextBlock { Text = prompt, Margin = new Thickness(0, 0, 0, 10) });

            var textBox = new TextBox { Text = defaultAnswer };
            stackPanel.Children.Add(textBox);

            var button = new Button
            {
                Content = "OK",
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 10, 0, 0),
                Width = 80
            };
            button.Click += (sender, e) =>
            {
                Answer = textBox.Text;
                DialogResult = true;
            };
            stackPanel.Children.Add(button);

            Content = stackPanel;
        }
    }
}