﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace BombCatcher
{
    public partial class Bomb : UserControl
    {
        public event EventHandler Missed;
        public bool IsFalling { get; set; } = true;

        public Bomb()
        {
            InitializeComponent();
        }

        public void CheckPosition(double canvasHeight)
        {
            if (IsFalling && Canvas.GetTop(this) >= canvasHeight - 10) // -10 для небольшого запаса
            {
                Missed?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}